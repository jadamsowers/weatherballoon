#define IDD_DIALOG1                     101
#define IDC_CONFIG                      1000
#define IDC_MAXCHANNELSSPIN             1001
#define IDC_MAXCHANNELS                 1002
